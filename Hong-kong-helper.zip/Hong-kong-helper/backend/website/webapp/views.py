from sys import stdout
from time import sleep
from django.shortcuts import render, redirect
import pymysql
import bcrypt
from hashids import Hashids
import random


def invite(request):
    if request.method == "POST":
        code = request.POST.get('code')
        db = pymysql.connect("18.191.88.191", "hkh123",
                             "FreeHK", "hkh", autocommit=True)
        cursor = db.cursor()
        sql = "SELECT * from invites where inviteCode = '%s'" % code
        cursor.execute(sql)
        results = cursor.fetchall()
        if len(results) == 1:
            cursor = db.cursor()
            delete = "delete from invites where inviteCode = '%s'" % code
            cursor.execute(delete)
            return render(request, "reg.html")
        else:
            return redirect("/")

    if request.method == "GET":
        return render(request, "invite.html")


def login(request):
    if request.method == "GET":
        return render(request, "login.html")
    else:
        username = request.POST.get('username')
        password = request.POST.get('password')
        city = request.POST.get('city')
        email = request.POST.get('email')

        # If any of the fields are empty, redirect to registration page
        if username == None or password == None or city == None or email == None:
            return redirect("/")

        # If the username already exosts, redirect to the registration page
        db = pymysql.connect("18.191.88.191", "hkh123",
                             "FreeHK", "hkh", autocommit=True)
        cursor = db.cursor()
        sql = "SELECT * FROM users where username = ('%s')" % (username)
        cursor.execute(sql)

        if cursor.rowcount != 0:
            return redirect("/")

        # User will have 3 keys generated and be directed to the login page
        else:
            usernum = random.randint(1, 1000000000000)
            # db = pymysql.connect("18.191.88.191","hkh123","FreeHK","hkh", autocommit=True)
            # cursor = db.cursor()
            hashed = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt())
            print(hashed)
            sql = "insert into users (username, password, email, city) values ('%s', '%s', '%s', '%s')" % (
                username, hashed.decode("utf-8"), email, city)
            hashids1 = Hashids(salt="freeeeeeee", min_length=6)
            hashids2 = Hashids(salt="Hoooonnng", min_length=6)
            hashids3 = Hashids(salt="Kooooooong", min_length=6)
            add1 = "insert into invites (username, inviteCode) values ('%s', '%s')" % (
                username, hashids1.encode(usernum))
            add2 = "insert into invites (username, inviteCode) values ('%s', '%s')" % (
                username, hashids2.encode(usernum))
            add3 = "insert into invites (username, inviteCode) values ('%s', '%s')" % (
                username, hashids3.encode(usernum))
            cursor.execute(sql)
            cursor.execute(add1)
            cursor.execute(add2)
            cursor.execute(add3)
            return render(request, "login.html")


def chat(request, username):
    if request.method == "GET":

        db = pymysql.connect("18.191.88.191", "hkh123",
                             "FreeHK", "hkh", autocommit=True)
        cursor = db.cursor()
        sql = "SELECT * FROM chats where username = ('%s')" % (username)
        cursor.execute(sql)
        result = cursor.fetchall()
        print("Result: " + str(result))
        return render(request, "chat.html", {"data": result, "username": username})


def chatroom(request, username, code):
    db = pymysql.connect("18.191.88.191", "hkh123",
                         "FreeHK", "hkh", autocommit=True)
    cursor = db.cursor()
    sql = "SELECT * FROM messages where code = ('%s')" % (code)
    cursor.execute(sql)
    result = cursor.fetchall()

    print("Result: " + str(result))

    return render(request, "chatroom.html", {"data": result, "username": username, "code": code})


def dashboard(request):
    if request.method == "POST":
        username = request.POST.get('username')
        password = request.POST.get('password')

        if username == None or password == None:
            redirect("/")

        db = pymysql.connect("18.191.88.191", "hkh123", "FreeHK", "hkh", autocommit=True)
        cursor = db.cursor()
        sql = "SELECT * FROM users where username = ('%s')" % (username)
        cursor.execute(sql)
        result = cursor.fetchone()

        if result[1] == username and bcrypt.checkpw(password.encode('utf-8'), result[2].encode('utf-8')):
            return render(request, "dashboard.html", {"data": username})
        else:
            return redirect("/")

    return render(request, "dashboard.html")


def maps(request):
    if request.method == "POST":
        db = pymysql.connect("18.191.88.191", "hkh123", "FreeHK", "hkh", autocommit=True)
        sql = "SELECT * FROM markers"
        cursor = db.cursor()
        cursor.execute(sql)
        results = cursor.fetchall()
        return render(request, "maps.html", {data: results})
    else: 
        desc = request.POST.get('description')
        type = request.POST.get('type')
        icon = request.POST.get('icon')
        cords = request.POST.get('cords')
        db = pymysql.connect("18.191.88.191", "hkh123", "FreeHK", "hkh", autocommit=True)
        cursor = db.cursor()
        sql = "INSERT INTO markers(description ,type, icon, coordinates, votes) VALUES ('%s','%s','%s','%s', 0)" % (desc, type, icon, cords)
        cursor.execute(sql)
        return render(request, "maps.html")
    
def notifications(request):
    return render(request, "notifications.html")
