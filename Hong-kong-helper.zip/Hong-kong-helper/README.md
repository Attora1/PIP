# Hong-kong-helper
A tool to help liberate Hong Kong
