import json
import mysql.connector
from sys import stdin, stdout
from time import sleep

while True:
    messagestr = stdin.readline().strip()
    print(messagestr)
    stdout.flush()
    # Holds instance of database connection
    db = mysql.connector.connect(
        user="hkh123",
        password="FreeHK",
        host="18.191.88.191",
        database="hkh"
    )

    cursor = db.cursor()
    messageJSON = json.loads(messagestr)

    # sql = "INSERT INTO messages(sentFrom, code, createdAt, message) VALUES('%s', '%s', NOW(), '%s' )" % (
    #     messageJSON['from'], messageJSON['code'], messageJSON['message'])
    try:
        # Execute the SQL command
        cursor.execute(sql)
        # Commit your changes in the database
        db.commit()
    except Exception as e:
        # Rollback in case there is any error
        db.rollback()
        print(e)

    # disconnect from server
    db.close()
